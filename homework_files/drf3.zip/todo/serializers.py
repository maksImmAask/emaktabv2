from rest_framework import serializers
from .models import Todo

class TodoSerializer(serializers.ModelSerializer):

    class Meta:
        model = Todo
        fields = '__all__'

    def validate_title(self, value):
        if len(value) < 3:
            raise serializers.ValidationError(
                'Минимум 3 символа'
            )
        return value

    def validate(self, attrs):
        if attrs.get('title', '').lower() == 'test':
            raise serializers.ValidationError(
                {'title': 'Название test запрещено'}
            )
        return attrs
