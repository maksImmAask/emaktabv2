Full DRF Todo Project

Features:
- CRUD
- JWT Authentication
- Validation
- Pagination
- Search
- Filtering
- Swagger (drf-spectacular)

Commands:
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver

Swagger:
/api/docs/

JWT:
POST /api/token/
POST /api/token/refresh/
